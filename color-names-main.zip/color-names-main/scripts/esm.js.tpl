export const colornames = "{{COLORS}}";
